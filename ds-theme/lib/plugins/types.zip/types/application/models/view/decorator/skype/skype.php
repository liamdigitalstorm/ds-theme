<?php

/**
 * Class Types_View_Decorator_Skype
 * @since 2.3
 */
class Types_View_Decorator_Skype implements Types_Interface_Value {

	/**
	 *
	 * @param array|string $value
	 * @param array $params
	 *
	 * @return string
	 */
	public function get_value( $value = '', $params = array() ) {
		// todo add new skype button output
		// see Types_View_Decorator_Skype_Legacy for outdated buttons
	}
}